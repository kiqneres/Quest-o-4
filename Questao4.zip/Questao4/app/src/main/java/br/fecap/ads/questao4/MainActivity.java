package br.fecap.ads.questao4;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import br.fecap.ads.questao4.R;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnIniciar = findViewById(R.id.btnIniciarPedido);
        btnIniciar.setOnClickListener(view -> {
            Intent intent = new Intent(this, PedidoActivity.class);


            startActivity(intent);
        });
    }
}
