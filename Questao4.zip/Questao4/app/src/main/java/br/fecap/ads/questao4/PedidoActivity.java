package br.fecap.ads.questao4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;



public class PedidoActivity extends AppCompatActivity {

    private TextInputEditText edtNome;
    private RadioGroup grupoLanches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        edtNome = findViewById(R.id.edtNome);
        grupoLanches = findViewById(R.id.grupoLanches);
        Button btnConfirmar = findViewById(R.id.btnConfirmar);

        btnConfirmar.setOnClickListener(v -> {
            String nome = edtNome.getText().toString().trim();
            int idSelecionado = grupoLanches.getCheckedRadioButtonId();

            if (nome.isEmpty() || idSelecionado == -1) {
                Toast.makeText(this, "Preencha seu nome e selecione um lanche.", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton rbSelecionado = findViewById(idSelecionado);
            String lanche = rbSelecionado.getText().toString();

            Intent intent = new Intent(PedidoActivity.this, ResumoActivity.class);
            startActivity(intent);
 
            intent.putExtra("nome", nome);
            intent.putExtra("lanche", lanche);
            startActivity(intent);
        });
    }
}
