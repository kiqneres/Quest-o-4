package br.fecap.ads.questao4;


import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class ResumoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo);

        TextView txtResumo = findViewById(R.id.txtResumo);
        Button btnNovoPedido = findViewById(R.id.btnNovoPedido);

        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String lanche = intent.getStringExtra("lanche");

        txtResumo.setText("Olá " + nome + ", seu pedido de " + lanche + " foi registrado com sucesso!");

        btnNovoPedido.setOnClickListener(v -> {
            Intent voltar = new Intent(this, MainActivity.class);
            voltar.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(voltar);
        });
    }
}
